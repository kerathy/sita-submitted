const classNames = {
  TODO_ITEM: 'todo-container',
  TODO_CHECKBOX: 'todo-checkbox',
  TODO_TEXT: 'todo-text',
  TODO_DELETE: 'todo-delete',
}

const list = document.getElementById('todo-list')
const itemCountSpan = document.getElementById('item-count')
const uncheckedCountSpan = document.getElementById('unchecked-count')

var count = 0;
var uncheckedCount = 0;
var newLi;

function newTodo() {

  newLi = document.createElement("input");
  newLi.setAttribute("type", "checkbox");
  newLi.setAttribute("checked", "checked");

  var newInput = document.createElement("input");
  newInput.setAttribute("type", "text");

  var removeBtn = document.createElement("button");
  removeBtn.innerHTML = "Remove";

  var newBr = document.createElement("br");

  list.appendChild(newLi);
  list.appendChild(newInput);
  list.appendChild(removeBtn);
  list.appendChild(newBr);

  count += 1;
  itemCountSpan.innerText = count;

  if (newLi.checked === true) {
    newLi.addEventListener("click", unCheck);
  }

  removeBtn.addEventListener("click", removeEve);
}

function unCheck() {
  uncheckedCount += 1;
  uncheckedCountSpan.innerText = uncheckedCount;
}

function removeEve() {
  console.log("remove item");
}